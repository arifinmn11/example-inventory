import React from 'react'

const ItemRow = ({ number, data }) => {
  return (
    <tr>
      <td> {number} </td>
      <td> {data.id} </td>
      <td> {data.name} </td>
      <td> {data.price} </td>
      <td>
        <button> edit </button>
        <button> delete </button>
      </td>
    </tr>
  )
}

export default ItemRow
