import React from 'react'

const Error = () => {
    return (
        <div>
            Page not found! 
        </div>
    )
}

export default Error
