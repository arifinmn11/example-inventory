import { delay } from "redux-saga/effects";
import { put, takeLatest } from "redux-saga/effects"
import {
  GET_ITEMS, GET_ITEMS_SUCCESS, GET_ITEMS_FAILURE
} from "../constants/actions"
import axios from "../configs/api"

function* getItems() {
  let result = yield axios.get(`/items`)
    .then(data => {
      return ({
        type: GET_ITEMS_SUCCESS,
        data: data
      })
    })
    .catch(err => {
      return ({
        type: GET_ITEMS_FAILURE,
        error: err
      })
    })
  yield put(result)
}

export function* watchGetItems() {
  yield takeLatest(GET_ITEMS, getItems)
}