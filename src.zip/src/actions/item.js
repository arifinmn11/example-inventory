import { GET_ITEMS } from "../constants/actions"

export function getAll() {
  return {
    type: GET_ITEMS
  }
}